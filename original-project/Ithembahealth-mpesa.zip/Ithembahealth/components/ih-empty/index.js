Component({ props:{ text:'' } });
